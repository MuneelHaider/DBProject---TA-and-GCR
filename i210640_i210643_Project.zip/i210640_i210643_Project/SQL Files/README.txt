C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA

Files of DBProject.mdf ad DBProject_log.ldf should be put into this place, if not working, use server management studio and add another DB.