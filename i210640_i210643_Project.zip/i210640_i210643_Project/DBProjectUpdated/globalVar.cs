﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBProject
{
    internal class globalVar
    {
        public static class GlobalVariables
        {
            public static string globalstring { get; set; } = "Bro";
            public static string globalstring2 { get; set; } = "bro";
            
        }
    }
}
